document.getElementById("sendBtn").addEventListener("click", async () => {
    const imageFile = document.getElementById("imageFile").files[0];
    const location = document.getElementById("location").value.trim();
    const resultEl = document.getElementById("result");

    if (!imageFile) {
      alert("请先选择一张图片文件");
      return;
    }
    if (!location) {
      alert("请输入地理位置");
      return;
    }

    resultEl.textContent = "正在上传图片...";

    const API_KEY = "app-55b3BLz4vubaUd7qoDoLUeok"; // ✅ 替换为实际 Dify API Key

    try {
      // ✅ 第一步：上传本地图片文件，获取 upload_file_id
      const uploadForm = new FormData();
      uploadForm.append("file", imageFile);
      const uploadResp = await fetch("https://api.dify.ai/v1/files/upload", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${API_KEY}`,
        },
        body: uploadForm,
      });

      if (!uploadResp.ok) {
        throw new Error("图片上传失败");
      }

      const uploadData = await uploadResp.json();
      const upload_file_id = uploadData.id; // ✅ 获取文件ID
      resultEl.textContent = "图片上传成功，正在生成分析结果...";

      // ✅ 第二步：向 Dify 工作流发送请求
      const requestBody = {
        inputs: {
          location: location,
          damageimage: {
            type: "image",
            transfer_method: "local_file", // ✅ 改为本地文件方式
            upload_file_id: upload_file_id, // ✅ 使用上传ID
          },
        },
        query: "请根据提供的图片和地理位置，生成生态相关分析",
        response_mode: "streaming",
        conversation_id: "",
        user: "user_000",
        files: [
          {
            type: "image",
            transfer_method: "local_file", // ✅ 本地上传方式
            upload_file_id: upload_file_id,
            name: "damageimage",
          },
        ],
      };

      const response = await fetch("https://api.dify.ai/v1/chat-messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${API_KEY}`,
        },
        body: JSON.stringify(requestBody),
      });

      if (!response.ok) {
        const err = await response.json().catch(() => ({}));
        throw new Error(`HTTP错误 ${response.status}：${JSON.stringify(err)}`);
      }

      if (!response.body) {
        throw new Error("响应不支持流式处理");
      }

      resultEl.textContent = "";
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let streamingText = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split("\n");
        for (const line of lines) {
          const trimmedLine = line.trim();
          if (trimmedLine.startsWith("data:")) {
            const dataPart = trimmedLine.slice(5).trim();
            if (dataPart) {
              try {
                const jsonData = JSON.parse(dataPart);
                if (jsonData.answer) {
                  streamingText += jsonData.answer;
                  resultEl.textContent = streamingText;
                }
              } catch {
                streamingText += dataPart;
                resultEl.textContent = streamingText;
              }
            }
          }
        }
      }

    } catch (error) {
      resultEl.textContent = "错误：" + error.message;
      console.error(error);
    }
  });