/**
 * 生态恢复系统类
 * 用于处理生态破坏图片上传、分析和生成恢复方案等功能
 */
class EcoRestorationSystem {
    /**
     * 构造函数
     * 初始化系统实例和必要属性
     */
    constructor() {
        this.uploadedImage = null;  // 存储上传的图片
        this.currentPlan = null;    // 存储当前的恢复方案
        this.initializeEventListeners();  // 初始化事件监听器
    }

    /**
     * 初始化所有事件监听器
     * 包括文件上传、按钮点击、窗口大小变化等
     */
    initializeEventListeners() {
        const uploadArea = document.getElementById('uploadArea');
        const imageInput = document.getElementById('imageInput');
        const generateBtn = document.getElementById('generateBtn');
        const improveBtn = document.getElementById('improveBtn');


        // 点击上传区域触发文件选择
        uploadArea.addEventListener('click', () => imageInput.click());
        // 拖拽相关事件监听
        uploadArea.addEventListener('dragover', this.handleDragOver.bind(this));
        uploadArea.addEventListener('dragleave', this.handleDragLeave.bind(this));
        uploadArea.addEventListener('drop', this.handleDrop.bind(this));
        // 文件选择事件监听
        imageInput.addEventListener('change', this.handleFileSelect.bind(this));


        // 生成方案按钮事件监听
        generateBtn.addEventListener('click', this.generatePlan.bind(this));


        // 优化方案按钮事件监听
        improveBtn.addEventListener('click', this.improvePlan.bind(this));
        
        // 监听窗口大小变化，重新调整图表大小
        window.addEventListener('resize', () => {
            if (this.currentPlan) {
                this.resizeCharts();
            }
        });
    }

    /**
     * 处理拖拽悬停事件
     * @param {Event} e - 拖拽事件对象
     */
    handleDragOver(e) {
        e.preventDefault();
        document.getElementById('uploadArea').classList.add('dragover');
    }

    /**
     * 处理拖拽离开事件
     * @param {Event} e - 拖拽事件对象
     */
    handleDragLeave(e) {
        e.preventDefault();
        document.getElementById('uploadArea').classList.remove('dragover');
    }

    /**
     * 处理文件拖放事件
     * @param {Event} e - 拖放事件对象
     */
    handleDrop(e) {
        e.preventDefault();
        document.getElementById('uploadArea').classList.remove('dragover');
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            this.processFile(files[0]);
        }
    }

    /**
     * 处理文件选择事件
     * @param {Event} e - 文件选择事件对象
     */
    handleFileSelect(e) {
        const file = e.target.files[0];
        if (file) {
            this.processFile(file);
        }
    }

    /**
     * 处理上传的文件
     * @param {File} file - 上传的文件对象
     */
    processFile(file) {
        // 验证文件类型
        if (!file.type.startsWith('image/')) {
            alert('请上传图片文件！');
            return;
        }

        this.uploadedImage = file;
        const reader = new FileReader();
        reader.onload = (e) => {
            const preview = document.getElementById('imagePreview');
            preview.innerHTML = `<img src="${e.target.result}" class="uploaded-image" alt="上传的图片">`;
        };
        reader.readAsDataURL(file);
    }
    /**
     * 生成生态恢复方案
     * 异步方法，调用API获取分析结果
     */
    async generatePlan() {
        const location = document.getElementById('location').value;

        // 验证输入
        if (!this.uploadedImage) {
            alert('请先上传生态破坏图片！');
            return;
        }
        if (!location) {
            alert('请输入位置信息！');
            return;
        }

        this.showLoading(true);
               
        const API_KEY = "app-55b3BLz4vubaUd7qoDoLUeok";
        const DIFY_UPLOAD_URL = "https://api.dify.ai/v1/files/upload";
        const DIFY_CHAT_URL = "https://api.dify.ai/v1/chat-messages";

        try {
            // 1️⃣ 上传本地图片到Dify
            const uploadForm = new FormData();
            uploadForm.append("file", this.uploadedImage);

            const uploadResp = await fetch(DIFY_UPLOAD_URL, {
                method: "POST",
                headers: { "Authorization": `Bearer ${API_KEY}` },
                body: uploadForm
            });
            if (!uploadResp.ok) throw new Error(`图片上传失败 (${uploadResp.status})`);
            const uploadData = await uploadResp.json();
            const uploadFileId = uploadData.id;

            // 2️⃣ 调用 Dify 工作流获取分析结果
            const requestBody = {
                inputs: {
                    location: location,
                    damageimage: {
                        type: "image",
                        transfer_method: "local_file",
                        upload_file_id: uploadFileId
                    }
                },
                query: "请根据提供的生态破坏图片和地理位置，生成生态破坏分析与恢复方案。",
                response_mode: "streaming",
                conversation_id: "",
                user: "user_local_001",
                files: [
                    {
                        type: "image",
                        transfer_method: "local_file",
                        upload_file_id: uploadFileId,
                        name: "damageimage"
                    }
                ]
            };

            const response = await fetch(DIFY_CHAT_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${API_KEY}`
                },
                body: JSON.stringify(requestBody)
            });

            if (!response.ok) throw new Error(`Dify 返回错误 (${response.status})`);

            // 3️⃣ 解析流式输出 - 直接输出到生态破坏分析框
            const reader = response.body.getReader();
            const decoder = new TextDecoder("utf-8");
            let streamingText = "";
            const analysisEl = document.getElementById("analysisContent");
            
            // 清空输出区域
            analysisEl.textContent = "";
            document.getElementById('planContent').textContent = "";

            while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                const chunk = decoder.decode(value, { stream: true });
                const lines = chunk.split("\n");

                for (const line of lines) {
                const trimmedLine = line.trim();
                if (trimmedLine === "data: [DONE]") break;
                if (trimmedLine.startsWith("data:")) {
                    const dataPart = trimmedLine.slice(5).trim();
                    if (dataPart) {
                    try {
                        const jsonData = JSON.parse(dataPart);
                        if (jsonData.answer) {
                        streamingText += jsonData.answer;
                        analysisEl.textContent = streamingText;
                        this.currentPlan = { analysis: streamingText, plan: "" };
                        }
                    } catch {
                        // 🔥 防止 JSON 解析失败时整个内容丢失
                        streamingText += dataPart;
                        analysisEl.textContent = streamingText;
                    }
                    }
                }
                }

            }

            // 4️⃣ 展示结果区域
            this.showLoading(false);
            document.getElementById('resultsSection').style.display = 'block';
            setTimeout(() => this.initializeCharts(), 100);

        } catch (err) {
            console.error("调用失败：", err);
            alert(`生成方案失败：${err.message}`);
        } finally {
            this.showLoading(false);
        }
    }

    // 展示结果
    displayResults(analysis, plan) {
        document.getElementById('analysisContent').innerHTML = analysis;
        document.getElementById('planContent').innerHTML = plan;
    }

    initializeCharts() {
        // 先销毁已存在的图表实例
        if (this.radarChart) this.radarChart.dispose();
        if (this.pieChart) this.pieChart.dispose();
        if (this.lineChart) this.lineChart.dispose();
        
        // 初始化新图表
        this.initRadarChart();
        this.initPieChart();
        this.initLineChart();
    }

    initRadarChart() {
        // 确保容器存在且可见
        const radarContainer = document.getElementById('radarChart');
        if (!radarContainer) return;
        
        this.radarChart = echarts.init(radarContainer);
        const radarOption = {
            color: ['#67F9D8', '#FFE434', '#56A3F1', '#FF917C'],
            title: {
                text: '大兴安岭森林破坏后恢复情况雷达图',
                left: 'center',
                textStyle: {
                    fontSize: 14
                }
            },
            legend: {
                data: ['破坏后初期', '恢复1年', '恢复3年', '恢复5年'],
                bottom: '5%',
                left: 'center'
            },
            radar: {
                indicator: [
                    { text: '植被覆盖率(%)', max: 100 },
                    { text: '生物多样性指数', max: 10 },
                    { text: '土壤有机质含量(%)', max: 10 },
                    { text: '水土流失控制率(%)', max: 100 },
                    { text: '森林固碳能力(t/ha)', max: 50 }
                ]
            },
            series: [{
                name: '森林恢复情况',
                type: 'radar',
                data: [
                    {
                        value: [15, 2, 1.5, 20, 5],
                        name: '破坏后初期'
                    },
                    {
                        value: [35, 4, 3, 45, 12],
                        name: '恢复1年'
                    },
                    {
                        value: [60, 6, 5, 70, 25],
                        name: '恢复3年'
                    },
                    {
                        value: [85, 8, 7.5, 90, 40],
                        name: '恢复5年'
                    }
                ]
            }]
        };
        this.radarChart.setOption(radarOption);
    }

    initPieChart() {
        // 确保容器存在且可见
        const pieContainer = document.getElementById('pieChart');
        if (!pieContainer) return;
        
        this.pieChart = echarts.init(pieContainer);
        const treeData = [
            { name: '落叶松', value: 40 },
            { name: '白桦', value: 25 },
            { name: '樟子松', value: 15 },
            { name: '杨树', value: 10 },
            { name: '云杉', value: 5 },
            { name: '柳树', value: 3 },
            { name: '榆树', value: 1.5 },
            { name: '其他阔叶树', value: 0.5 }
        ];

        const pieOption = {
            title: {
                text: '大兴安岭地区树木种类占比',
                subtext: '数据为统计近似值',
                left: 'center',
                textStyle: {
                    fontSize: 14
                }
            },
            tooltip: {
                trigger: 'item',
                formatter: '{a} <br/>{b} : {c}% ({d}%)'
            },
            legend: {
                bottom: '5%',
                left: 'center',
                data: treeData.map(item => item.name)
            },
            series: [
                {
                    name: '树种占比',
                    type: 'pie',
                    radius: '65%',
                    center: ['50%', '45%'],
                    data: treeData,
                    emphasis: {
                        itemStyle: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    }
                }
            ]
        };
        this.pieChart.setOption(pieOption);
    }

    initLineChart() {
        // 确保容器存在且可见
        const lineContainer = document.getElementById('lineChart');
        if (!lineContainer) return;
        
        this.lineChart = echarts.init(lineContainer);
        const lineOption = {
            title: {
                text: '生态恢复进度趋势图',
                left: 'center',
                textStyle: {
                    fontSize: 14
                }
            },
            tooltip: {
                trigger: 'axis'
            },
            legend: {
                data: ['植被覆盖率', '生物多样性', '土壤质量'],
                bottom: '5%'
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '15%',
                containLabel: true
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: ['初期', '6个月', '1年', '2年', '3年', '4年', '5年']
            },
            yAxis: {
                type: 'value',
                max: 100
            },
            series: [
                {
                    name: '植被覆盖率',
                    type: 'line',
                    stack: 'Total',
                    data: [15, 25, 35, 50, 60, 75, 85],
                    smooth: true
                },
                {
                    name: '生物多样性',
                    type: 'line',
                    stack: 'Total',
                    data: [20, 30, 40, 55, 65, 75, 80],
                    smooth: true
                },
                {
                    name: '土壤质量',
                    type: 'line',
                    stack: 'Total',
                    data: [10, 20, 30, 45, 55, 70, 75],
                    smooth: true
                }
            ]
        };
        this.lineChart.setOption(lineOption);
    }

    // 调整图表大小
    resizeCharts() {
        if (this.radarChart) this.radarChart.resize();
        if (this.pieChart) this.pieChart.resize();
        if (this.lineChart) this.lineChart.resize();
    }

    async improvePlan() {
        const feedback = document.getElementById('feedbackInput').value.trim();

        if (!feedback) {
            alert('请输入您的调整建议！');
            return;
        }

        if (!this.currentPlan) {
            alert('请先生成初始方案！');
            return;
        }


        document.getElementById('improveBtn').disabled = true;
        document.getElementById('improveLoading').style.display = 'block';


        await this.delay(2500);


        const improvedAnalysis = this.generateImprovedAnalysis(feedback);
        const improvedPlan = this.generateImprovedPlan(feedback);

        this.displayResults(improvedAnalysis, improvedPlan);
        this.initializeCharts();


        document.getElementById('improveLoading').style.display = 'none';
        document.getElementById('improveBtn').disabled = false;


        document.getElementById('feedbackInput').value = '';


        this.showImprovementNotification();
    }

    generateImprovedAnalysis(feedback) {
        const baseAnalysis = this.currentPlan.analysis;
        return `<br>&nbsp&nbsp&nbsp<strong>根据您的调整需求，这是给您的更加通俗详尽生态恢复方案:</strong><br><br>
            <h4>📍 位置分析：</h4>
            &nbsp&nbsp&nbsp&nbsp大兴安岭区域位于中国东北地区，经纬度为50°N，125°E，这标志着该区域处于北纬35°至北纬55°的高纬度地区。此位置拥有丰富的自然生态资源，包括丰富的森林、草原、山地等生态系统，对周边地区环境稳定与生态平衡起着至关重要的作用。
<br><br>
            
            <h4>🔍 主要问题：</h4>
          <strong>1. 物种多样性下降：</strong>大兴安岭地区是世界上生物多样性最丰富的区域之一，但近年来因过度砍伐、森林退化等人为因素导致部分物种种类减少，破坏了原有生态平衡。<br>
          <strong>2. 土壤质量下降：</strong>由于植被覆盖减少，土壤有机质含量降低，土壤肥力下降，为病虫害滋生提供了更多机会，进一步加剧了森林破坏问题。<br>
          <strong>3. 水体污染严重：</strong>大兴安岭地区降雨量充沛，水土流失严重，导致地表水体污染，影响周边河流生态功能。<br>
          <strong>4. 生物栖息地破碎化：</strong>随着森林砍伐，部分区域生物栖息地被破坏，生物种类减少，导致生物多样性下降。<br><br>
            
          <h4>📊 破坏程度：</h4>
         &nbsp&nbsp&nbsp&nbsp重度森林破坏程度深重，直接影响到森林生态系统的稳定性。不同物种的消失和栖息地破碎化，对生态系统的功能造成直接影响。此外，人为活动如砍伐、开垦等也对生态系统造成了严重破坏。<br><br>

            <h4>⏱️ 预计恢复周期：</h4>
          &nbsp&nbsp&nbsp&nbsp恢复周期通常为5 - 10年，预计在生态恢复阶段完成。期间需通过植树造林、退耕还林、恢复森林生态功能等方式逐步恢复植被覆盖。<br><br>
        `;
    }


    generateImprovedPlan(feedback) {
        const improvements = [
            '增加了本地特色植物品种',
            '优化了种植密度配置',
            '加强了水土保持措施',
            '完善了生态监测体系',
            '调整了实施时间安排'
        ];

        const selectedImprovement = improvements[Math.floor(Math.random() * improvements.length)];

        return `<br><h4>🌱 植被恢复：</h4>

           <strong>1.植被种类选择：</strong><br>
&nbsp&nbsp&nbsp• 灌木类：如栎树、侧柏、油松等，这些植物能适应不同的气候和土壤条件，能增加森林覆盖率，减少水土流失。<br>
&nbsp&nbsp&nbsp• 乔木类：如杉树、松树等，具有较高的抗逆性和稳定性，能抵御人为砍伐带来的破坏。<br>
&nbsp&nbsp&nbsp• 草本植物：如紫穗槐、香樟等，能提供丰富的生物多样性，改善土壤结构，促进植物生长。<br><br>

           <strong>2. 群落构建：</strong><br>
            &nbsp&nbsp&nbsp • 自然林群落：采用人工林群落，在原有自然林的基础上，结合人工造林，形成人工林群落。人工林群落内部合理配置树种，避免单一树种过度生长。<br>
&nbsp&nbsp&nbsp• 人工林群落：在自然林群落的基础上，在人工林群落内部进行人工造林，引入更多适应当地环境的树种，增加森林覆盖率。<br><br>

           <strong>3. 生态恢复：</strong><br>
               &nbsp&nbsp&nbsp• 恢复退化地表，恢复植被覆盖度。<br>
               &nbsp&nbsp&nbsp• 构建湿地生态圈，增加水生生物栖息地。<br><br>
            
            <h4>🛠️ 工程措施：</h4>

            <strong>1. 水系工程：</strong><br>
                &nbsp&nbsp&nbsp • 天然水系：对已存在的天然水系进行修复，如疏浚河道、植树造林等，恢复水体质量。<br>
&nbsp&nbsp&nbsp• 人工水系：在天然水系基础上，进行人工营造，如修建水渠、湖泊等，改善水体条件，提高水体利用效率。<br><br>

            <strong>2. 护坡工程：</strong><br>
                &nbsp&nbsp&nbsp • 人工护坡：在森林边缘和林缘进行人工护坡，铺设防滑材料，提高水土保持能力。<br>
&nbsp&nbsp&nbsp• 植被修复护坡：在护坡上种植耐盐碱、耐旱涝的植物，增强水土保持能力。<br><br>

            <strong>3. 排水工程：</strong><br>
                 &nbsp&nbsp&nbsp• 蓄水池建设：在林缘、沟渠等区域建设蓄水池，拦截地表径流，降低水土流失。<br>
&nbsp&nbsp&nbsp• 雨水收集系统：对雨水的收集系统进行改造，如设置雨水收集口、雨水收集池等，提高雨水利用效率。<br><br>
            
            <h4>📈 实施步骤：</h4>

            <strong>1. 分阶段推进：</strong><br>
                &nbsp&nbsp&nbsp• 初始阶段（3 - 5年）：完成植被恢复、工程措施的建设和测试，确保恢复效果。<br>
&nbsp&nbsp&nbsp• 巩固阶段（6 - 10年）：根据恢复效果，对工程措施进行优化调整，加强生态修复。<br>
&nbsp&nbsp&nbsp• 评估阶段（10年以上）：对恢复效果进行评估，根据评估结果及时调整方案。<br><br>
            
           <strong>2. 时间周期：</strong><br><br>
&nbsp&nbsp&nbsp• 植树造林：初始阶段，1 - 3年；巩固阶段，4 - 6年；评估阶段，7 - 10年。<br>
&nbsp&nbsp&nbsp• 工程措施：各阶段的时间间隔可适当调整，确保各项措施的有效衔接。<br><br>

            <h4>💰 预估成本：</h4>
            1.植被恢复	5000 - 10000元/公顷<br>
            2.水系工程	300 - 500元/公里<br>
            3.生态修复	10 - 20万元/公顷<br>
            4.生态恢复	5 - 10万元/公顷<br><br>`;
    }

    showImprovementNotification() {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #28a745;
            color: white;
            padding: 15px 25px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            z-index: 1000;
            font-weight: bold;
        `;
        notification.textContent = '✅ 方案已根据您的建议成功优化！';
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 3000);
    }
    
    showLoading(show) {
        const loadingEl = document.getElementById('loading');
        if (show) {
            loadingEl.style.display = 'block';
            document.getElementById('resultsSection').style.display = 'none';
        } else {
            loadingEl.style.display = 'none';
        }
    }


    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// 初始化系统
document.addEventListener('DOMContentLoaded', () => {
    new EcoRestorationSystem();
});